string = input("enter a string:-")
if(string==string[::-1]):
    print("It is a plindrome!")
else:
    print("it is not a palindrom!")