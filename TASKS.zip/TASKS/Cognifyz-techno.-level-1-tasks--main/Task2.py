print("*******Temperature Conversion*******")
celsius =float(input("enter temperature in celsius: "))
fahrenheit = (celsius * 1.8) + 32
print("%.2f Celsius = %.2f Fahrenheit" %(celsius,fahrenheit))