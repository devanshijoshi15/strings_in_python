print("********String Reversal********")
def reverse_string(string1):
    revstr=string1[::-1]

    return revstr
string1=input("enter a string:")
r=reverse_string(string1)
print(r)
    